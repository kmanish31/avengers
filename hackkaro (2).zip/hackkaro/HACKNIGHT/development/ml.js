// npm
var express = require('express');
var request = require('request');

// routes
var router = express.Router();
router.post('/', (req, res) => {
	// web service details
	var webServiceUrl = "https://ussouthcentral.services.azureml.net/workspaces/a1f97639bbfd45acb3f9e5f60dbffe74/services/ed2de9eed927490eb22a6ffa0d487e45/execute?api-version=2.0&format=swagger";
    //var webServiceUrl ="https://ussouthcentral.services.azureml.net/workspaces/a1f97639bbfd45acb3f9e5f60dbffe74/services/ed2de9eed927490eb22a6ffa0d487e45/execute?api-version=2.0&details=true";
	//var apiKey = "p64hx6Hlsl/hEstvZjzwTE9QSuzWTGtc1OKPgCLV7Xmh6otnQ4b0WnH3o8debzy2KZV9ovFS0WV1qNAMoQtC7Q==";
	var apiKey = "p64hx6Hlsl/hEstvZjzwTE9QSuzWTGtc1OKPgCLV7Xmh6otnQ4b0WnH3o8debzy2KZV9ovFS0WV1qNAMoQtC7Q=="

	// data
	var data = {
		"Inputs":{
			"input1":[
				{
					'Timestamp': req.body.timestamp,
					'Age': req.body.age,
                    'Gender': req.body.gender,
					'Country': req.body.contry,
					'State': req.body.st,
					'Self-Employed': req.body.self_emp,
					'Family-History': req.body.fam_his,
					'Work_Interfere': req.body.work_int,
					'No_Of_Employees': req.body.no_of_emp,
					'Remote_work': req.body.remote_work,
                    'Tech_Company': req.body.tech_comp,
                    'Benefits': req.body.benefits,
                    'Care_Options': req.body.care_opt,
                    'Wellness_Prog': req.body.wellness_prog,
                    'Seek_Help': req.body.seek_help,
                    'Anonymity': req.body.anonymity,
                    'Leave': req.body.leave,
                    'Mental_Health_Consequence': req.body.mhc,
                    'Physical_Health_Consequence': req.body.phc,
                    'Coworkers': req.body.coworkers,
                    'Supervisors': req.body.supervisors,
                    'Mental_Health_Interview': req.body.mhi,
                    'Physical_Health_Interview': req.body.phi,
                    'Mental_Vs_Physical': req.body.mvp,
                    'Obs_Consequence': req.body.obs,
                    'Comments': req.body.comm,
				}
			]
		},
		"GlobalParameters":{}
	}

	// request
	var options = {
		method: 'POST',
		port: 3000,
		uri: webServiceUrl,
		headers: {
			'Content-Type': 'application/json',
			'Authorization': "Bearer " + apiKey
		},
		body: JSON.stringify(data)
	}

	request(options, (error, response, body) => {
		res.send(body);
	});

});

module.exports = router;